//
//  OhelloGameApp.swift
//  OhelloGame
//
//  Created by Ming Xia on 3/23/22.
//

import SwiftUI

@main
struct OhelloGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
